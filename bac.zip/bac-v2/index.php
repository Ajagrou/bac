<?php
require 'head.php';
?>

<div class="main">
<form method="POST" action="read.php">
    <p>نقط الامتحان الوطني</p>
    <input step="0.01" min="0.00" max="20.00" class="input-btn" type="number" placeholder="الرياضيات" name="math" required><br>
    <input step="0.01" min="0" max="20" class="input-btn" type="number" placeholder="العلوم الفيزيائية" name="ph" required><br>
    <input step="0.01" min="0" max="20" class="input-btn" type="number" placeholder="علوم الحياة و الأرض" name="svt"required><br>
    <input step="0.01" min="0" max="20" class="input-btn" type="number" placeholder="اللغة الانجليزية" name="en" required><br>
    <input step="0.01" min="0" max="20"class="input-btn" type="number" placeholder="الفلسفة" name="phi" required><br>
    <p>نقط المراقبة المستمرة</p>
    <input step="0.01" min="0" max="20"class="input-btn" type="number" placeholder="الدورة الاولى" name="dawra1" required><br>
    <input step="0.01" min="0" max="20"class="input-btn" type="number" placeholder="الدورة الثانية" name="dawra2" required><br>
    <p>نقطة الامتحان الجهوي</p>
    <input step="0.01" min="0" max="20"class="input-btn" type="number" placeholder="نقطة الامتحان الجهوي" name="jihawi" required><br>
    <input class="sub-btn" type="submit" value="حساب"  name="#"><br>
</form>
</div>