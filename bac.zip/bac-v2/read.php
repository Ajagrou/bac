<?php
require 'head.php';
if ($_SERVER["REQUEST_METHOD"] === "POST"){
    $math = $_POST['math'];
    $ph = $_POST['ph'];
    $svt = $_POST['svt'];
    $en = $_POST['en'];
    $phi = $_POST['phi'];
    $dawra1 = $_POST['dawra1'];
    $dawra2 = $_POST['dawra2'];
    $jihawi = $_POST['jihawi'];
    }
$stat =  "لاشي";
$dawra3 = $dawra1 + $dawra2 ;
$dawra = $dawra3 / 2 ;
$tot = $jihawi + $dawra ;
$tot2 = $tot / 2 ;
$m1 = 7;
$m2 = 2;
$m3 = 5 ;
$m4 = 23;
$total1 = $math*$m1 + $ph*$m1 + $svt*$m3 + $phi*$m2 + $en*$m2;
$total2 = $total1 / $m4;
$total3 = sprintf("%.2f", $total2);
$total0 = $total2 + $tot2;
$totalfinal = $total0 / 2;
$total = sprintf("%.2f", $totalfinal);
if ($total>= 10 ) {
    $stat = "مزيان";
    if ($total<= 8 ) {
        $stat = "جمع كرك !";
    }
}
?>
<body class="page2">
    </div>
    <div id="showid" class="show-main">
    <div class="show">
        <p>الرياضيات : <?php echo $math ?></p>
        <p>العلوم الفيزيائية : <?php echo $ph ?></p>
        <p>علوم الحياة و الأرض : <?php echo $svt ?></p>
        <p>اللغة الانجليزية : <?php echo $en ?></p>
        <p>الفلسفة : <?php echo $phi ?></p>
        <p>المراقبة المستمرة : <?php echo $dawra ?></p>
        <p>نقطة الامتحان الجهوي : <?php echo $jihawi ?></p>
        <p>نقطة الامتحان الوطني : <?php echo $total3 ?></p>
        <p>نقطة الباكالوريا  : <?php echo $total ?> </p>
        <a href="../index.php"><input class="sub-btn1" value="إلغاء" type="submit" name="" id="cancel"></a>
        <form class="print" action="print.php" method="POST">
  <input class="printin" type="number" name="variable1" value=<?php echo $math; ?>>
  <input class="printin" type="number" name="variable2" value=<?php echo $ph; ?>>
  <input class="printin" type="number" name="variable3" value=<?php echo $svt; ?>>
  <input class="printin" type="number" name="variable4" value=<?php echo $en; ?>>
  <input class="printin" type="number" name="variable5" value=<?php echo $phi; ?>>
  <input class="printin" type="number" name="variable6" value=<?php echo $dawra; ?>>
  <input class="printin" type="number" name="variable7" value=<?php echo $jihawi; ?>>
  <input class="printin" type="number" name="variable8" value=<?php echo $total3; ?>>
  <input class="printin" type="number" name="variable9" value=<?php echo $total; ?>>
  <button id="showme-button" class="sub-btn1" type="submit" >طباعة</button>
</form>  
    </div>
</div>
<div id="item-to-hide" class="pop-final">
  <div>
    <img class="animated-image" src="style/check.png" alt=""><br>
    <a href="../index.php"><input class="sub-btn2" value="إلغاء" type="submit" name="" id="item-to-toggle"></a>
  </div>
    </div>
<script>
  document.getElementById('submitBtn').addEventListener('click', function() {
    // Set the variables
    var variable1 = "Value 1";
    var variable2 = "Value 2";
    var variable3 = "Value 3";
    var variable4 = "Value 4";
    var variable5 = "Value 5";
    var variable6 = "Value 6";
    var variable7 = "Value 7";
    var variable8 = "Value 8";
    var variable9 = "Value 9";

    // Create a new XMLHttpRequest object
    var xhttp = new XMLHttpRequest();

    // Define the AJAX request
    xhttp.onreadystatechange = function() {
      if (this.readyState === 4 && this.status === 200) {
        // Process the response from the PHP file
        console.log(this.responseText);
      }
    };

    // Send the AJAX request to the PHP file
    xhttp.open("POST", "print.php", true);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.send("variable1=" + variable1 + "&variable2=" + variable2 + "&variable3=" + variable3 + "&variable4=" + variable4 + "&variable5=" + variable5 + "&variable6=" + variable6 + "&variable7=" + variable7 + "&variable8=" + variable8 + "&variable9=" + variable9);
  });
</script>
<script>
  window.addEventListener('load', function() {
  var itemToHide = document.getElementById('item-to-hide');
  itemToHide.classList.add('hidden');
});

</script>
<script>
  var showButton = document.getElementById('showme-button');
var itemToToggle = document.getElementById('item-to-hide');

showButton.addEventListener('click', function() {
  itemToToggle.classList.remove('hidden');
});

</script>
</body>
