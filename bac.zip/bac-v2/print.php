<?php
require 'fpdf.php';



if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $variable1 = $_POST['variable1'];
  $variable2 = $_POST['variable2'];
  $variable3 = $_POST['variable3'];
  $variable4 = $_POST['variable4'];
  $variable5 = $_POST['variable5'];
  $variable6 = $_POST['variable6'];
  $variable7 = $_POST['variable7'];
  $variable8 = $_POST['variable8'];
  $variable9 = $_POST['variable9'];
}

class MyPDF extends FPDF {
    // ...
    function Header() {
        // Set up the header of the PDF document
        // Example: Add a company logo or text
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(0, 10, 'Baccalaureat Note', 0, 1, 'C');
      }
    function Content($variable1 , $variable2 , $variable3 , $variable4 , $variable5 , $variable6 , $variable7 , $variable8 , $variable9) {
      $this->SetFont('Arial', '', 12);
      $this->Cell(0, 10, 'Mathematiques : ' . $variable1, 0, 1);
      $this->Cell(0, 10, 'Physique Chimie : ' . $variable2, 0, 1);
      $this->Cell(0, 10, 'Sciences de la Vie et de la Terre : ' . $variable3, 0, 1);
      $this->Cell(0, 10, 'ENGLISH : ' . $variable4, 0, 1);
      $this->Cell(0, 10, 'Philosophie : ' . $variable5, 0, 1);
      $this->Cell(0, 10, 'Controle Continu : ' . $variable6, 0, 1);
      $this->Cell(0, 10, 'Regional : ' . $variable7, 0, 1);
      $this->Cell(0, 10, 'National : ' . $variable8, 0, 1);
      $this->SetFont('Arial', 'B', 12);
      $this->Cell(0, 10, 'La Note Finale de : ' . $variable9, 0, 1);

    }
    function Footer() {
        $this->SetFont('Arial', 'B', 12);
        $this->Cell(0, 100, 'thanks Yassine Ajagrou <3', 0, 1, 'C');
      }
  }
  
  
  $pdf = new MyPDF();
  $pdf->AliasNbPages();
  $pdf->AddPage();
  $pdf->Content($variable1 , $variable2 , $variable3 , $variable4 , $variable5 , $variable6 , $variable7 , $variable8 , $variable9 );
  $pdf->Output();
?>
